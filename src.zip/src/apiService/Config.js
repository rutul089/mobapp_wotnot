
export const appName = 'Clear-vue';
export const STATUS_CODE = {
  200: 'Working fine',
};

