import React from 'react';
import LoginLogo from './login/logo.svg';

export const SVG = {
  LoginLogoIcon: () => <LoginLogo height={54} width={164} />,
};
