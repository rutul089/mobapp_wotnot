import Tabs from './Tabs';

export { Tabs };
export type { ITabsProps } from './types';
