import React,{createContext,useEffect,useState} from 'react';
import { AppState } from 'react-native';    


export const AppStateContext = createContext();

const CurrentAppState = () => {
    let [appState,setAppState] = useState(AppState.currentState);
  
    const handleStateChange = (state) => {
        setAppState(state);
    }
    useEffect(() => {
        AppState.addEventListener('change',handleStateChange);
        return (() => {
            AppState.removeEventListener('change');
        }) 
    },[])
   
    return {
        appState: appState
    }
};

export default CurrentAppState;