//Lib
import {createContext, useEffect, useState} from 'react';

// Socket events
import {
  changeUserStatus,
  emitSwitchConversationMode,
  emitAgentTyping,
  disconnect,
  agentLeave,
} from '../../websocket/index';
import {LOCAL_STORAGE} from '../../constants/storage';
import {setItemToStorage, multiGet} from '../../util/DeviceStorageOperations';

// import {LOCALSTORAGE} from '~/common/constants';
// import { setItemToStorage, multiGet } from '~/utils/DeviceStorageOperations';

export const SocketEventsContext = createContext();

const SocketEvents = () => {
  const [usertData, setUserData] = useState({
    userPreference: null,
    agentAccountList: null,
    userList: null,
    notificationConfiguration: null,
  });

  const [chatListingCounts, setChaLisitngCounts] = useState({
    You: 0,
    Assigned: 0,
    Unassigned: 0,
  });
  const [receivedMsg, setIsReceivedMsg] = useState('');
  const [receivedConvCreate, setIsReceivedConvCreate] = useState([]);
  const [userStatus, setUserStatus] = useState();
  const [socket, setSocket] = useState();
  const [typingData, setTypingData] = useState();
  const [msgRead, setMsgRead] = useState();
  const [assigneeChange, setAssigneeChange] = useState();
  const [statusChange, setStatusChange] = useState();
  const [newNote, setNewNote] = useState();
  const [customerProfile, setCustomerProfile] = useState();
  const [selectAccountId, setAccountId] = useState();
  const [notificationAccountId, setNotificationAccountId] = useState();

  const onChangeUserData = data => {
    setUserData({
      ...usertData,
      ...data,
    });
  };
  useEffect(() => {
    let initialState = async () => {
      let data = await multiGet([
        LOCAL_STORAGE.USER_PREFERENCE,
        LOCAL_STORAGE.AGENT_ACCOUNT_LIST,
      ]);
      onChangeUserData({
        userPreference: data[LOCAL_STORAGE.USER_PREFERENCE],
        agentAccountList: data[LOCAL_STORAGE.AGENT_ACCOUNT_LIST],
        // userList:data[LOCALSTORAGE.USER_LIST],
        // notificationConfiguration:data[LOCALSTORAGE.NOTIFICATION_CONFIGURATION],
      });
    };
    initialState();
  }, []);
  useEffect(() => {
    const updateLocalStorage = async () => {
      setItemToStorage(LOCAL_STORAGE.USER_PREFERENCE, usertData.userPreference);
      setItemToStorage(
        LOCAL_STORAGE.AGENT_ACCOUNT_LIST,
        usertData.agentAccountList,
      );
      //     setItemToStorage(LOCALSTORAGE.USER_LIST,usertData.userList);
      //     setItemToStorage(LOCALSTORAGE.NOTIFICATION_CONFIGURATION,usertData.notificationConfiguration);
    };
    updateLocalStorage();
  }, [usertData]);

  // chatscreen bottom menu related operations
  const [isChatScreenMenuOpen, setChatScreenMenuOpen] = useState(false);
  const toggleChatScreenMenu = (val = false) => {
    setChatScreenMenuOpen(val);
  };

  const onChangeNotificationAccountId = (id = null) => {
    setNotificationAccountId(id);
  };

  const onChangeCounts = payload => {
    setChaLisitngCounts(payload);
  };

  const onChangeVisitorTyping = payload => {
    setTypingData(payload);
  };

  const onMsgReceived = payload => {
    setIsReceivedMsg(payload);
  };

  const onConvCreateReceived = (payload, isSetFromChatList = false) => {
    if (isSetFromChatList) {
      setIsReceivedConvCreate(payload);
    } else {
      setIsReceivedConvCreate(oldArray => [...oldArray, payload]);
    }
  };

  const onChangeUserStatus = payload => {
    setUserStatus(payload);
  };

  const onChangeSocket = payload => {
    setSocket(payload);
  };

  const onMsgRead = payload => {
    setMsgRead(payload);
  };

  const onAssigneeChange = payload => {
    setAssigneeChange(payload);
  };

  const onStatusChanged = payload => {
    setStatusChange(payload);
  };

  const onNewNoteAdd = payload => {
    let convertPayload = {
      agent: payload.agent,
      bot_id: payload.bot_id,
      bot_title: null,
      conversation_key: payload.conversation_key,
      global_channel_name: null,
      is_new_conversation: false,
      ok: true,
      user_message: null,
      visitor_name: null,
    };
    convertPayload['agent']['note'] = payload.event_payload.note;
    convertPayload['agent']['timestamp'] = 'now';
    setNewNote(convertPayload);
  };

  const emitUserStatus = async (_status, userId = null) => {
    if (socket) {
      setUserStatus({
        ...userStatus,
        status: _status ? 'online' : 'away',
      });
      if (_status === true) {
        changeUserStatus({
          status: 'online',
          status_id: 1,
          user_id: userId ? userId : userStatus.user_id,
        });
      } else {
        changeUserStatus({
          status: 'away',
          status_id: 2,
          user_id: userId ? userId : userStatus.user_id,
        });
      }
    }
  };

  const emitAgentLeave = async payload => {
    agentLeave(payload);
    disconnect();
  };

  const onCustomerProfile = payload => {
    setCustomerProfile(payload);
  };

  const onEmitConversationModeChange = payload => {
    emitSwitchConversationMode(payload);
  };

  const onEmitAgentTyping = payload => {
    emitAgentTyping(payload);
  };

  const onAccountIdChange = id => {
    setAccountId(id);
  };

  return {
    notificationAccountId: notificationAccountId,
    userPreference: usertData.userPreference,
    agentAccountList: usertData.agentAccountList,
    userList: usertData.userList,
    notificationConfiguration: usertData.notificationConfiguration,
    chatCounts: chatListingCounts,
    msg: receivedMsg,
    createConversationMsg: receivedConvCreate,
    note: newNote,
    userStatus: userStatus,
    typingMsg: typingData,
    readMsg: msgRead,
    msgAssigneeChange: assigneeChange,
    msgStatusChange: statusChange,
    customerProfile: customerProfile,
    selectAccountId: selectAccountId,
    onChangeCounts: onChangeCounts,
    onChangeVisitorTyping: onChangeVisitorTyping,
    onChangeUserStatus: onChangeUserStatus,
    onChangeSocket: onChangeSocket,
    emitUserStatus: emitUserStatus,
    emitAgentLeave: emitAgentLeave,
    onMsgReceived: onMsgReceived,
    onConvCreateReceived: onConvCreateReceived,
    onMsgRead: onMsgRead,
    onAssigneeChange: onAssigneeChange,
    onStatusChanged: onStatusChanged,
    onNewNoteAdd: onNewNoteAdd,
    isChatScreenMenuOpen: isChatScreenMenuOpen,
    toggleChatScreenMenu: toggleChatScreenMenu,
    onCustomerProfile: onCustomerProfile,
    onEmitConversationModeChange: onEmitConversationModeChange,
    onEmitAgentTyping: onEmitAgentTyping,
    onAccountIdChange: onAccountIdChange,
    onChangeUserData: onChangeUserData,
    onChangeNotificationAccountId: onChangeNotificationAccountId,
  };
};

export default SocketEvents;
