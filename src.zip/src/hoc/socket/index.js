// Lib
import React, {useEffect, useState, useContext} from 'react';
import AsyncStorage from '@react-native-community/async-storage';

// HOC and Context

import {SocketEventsContext} from '../../context/socketevents';
import {AppStateContext} from '../../context/appstate';

// Constants and Helpers

import {LOCAL_STORAGE} from '../../constants/storage';

// Socket events
import {
  initSocket,
  emitAgentJoin,
  registerUserStatus,
  registerVisitorTypingHandler,
  registerMessageHandler,
  registerConversationCreateHandler,
  registerMessageRead,
  registerAssigneeChangedHandler,
  registerStatusChangedHandler,
  registerNote,
  registerCustomerProfile,
  reconnect,
} from '../../websocket/index';
import {getItemFromStorage} from '../../util/DeviceStorageOperations';

const SocketHOC = Component => props => {
  const appstate = useContext(AppStateContext);
  const [socket, setSocket] = useState();
  const {
    onChangeSocket,
    onMsgReceived,
    onConvCreateReceived,
    onChangeUserStatus,
    onChangeVisitorTyping,
    onMsgRead,
    onAssigneeChange,
    onStatusChanged,
    onNewNoteAdd,
    onCustomerProfile,
    onChangeUserData,
  } = useContext(SocketEventsContext);

  const getUserStatus = status => {
    const updateStatusIfLoggedInUser = async () => {
      try {
        let userPref = await getItemFromStorage(LOCAL_STORAGE.USER_PREFERENCE);
        // only if status id is equal to logged in user id then only that time call onChangeUserStatus update user status
        status && userPref && status.user_id === userPref?.logged_in_user_id
          ? onChangeUserStatus(status)
          : null;
      } catch (err) {
        console.log(err);
      }
    };
    updateStatusIfLoggedInUser();
  };

  const visitorTYping = data => {
    onChangeVisitorTyping(data);
  };

  const onMessageReceived = msg => {
    msg ? onMsgReceived(msg) : null;
  };

  const onConversationCreateReceived = msg => {
    msg ? onConvCreateReceived(msg) : null;
  };

  const onAddNote = msg => {
    msg ? onNewNoteAdd(msg) : null;
  };

  const onMessageRead = msg => {
    msg ? onMsgRead(msg) : null;
  };

  const onAssigneeStatusChange = msg => {
    msg ? onAssigneeChange(msg) : null;
  };

  const onMsgStatusChanged = msg => {
    msg && msg.conversation_key ? onStatusChanged(msg) : null;
  };

  const onCustomerProfileChanged = msg => {
    msg ? onCustomerProfile(msg) : null;
  };

  useEffect(() => {
    if (socket) {
      onChangeSocket(socket);
    }
  }, [socket]);

  let connectSocket = async () => {
    try {
      var userPref = await AsyncStorage.getItem(
        LOCAL_STORAGE.USER_PREFERENCE,
      );
    //   let userPref = await getItemFromStorage(LOCAL_STORAGE.USER_PREFERENCE);
      console.log('---------------->', JSON.stringify(userPref));
      //   if (!userPref) {
      //     console.log('----------------')
      //     // await initialApiCalls({apiCall:apiCall,onChangeUserData:onChangeUserData});
      //   }
      let socket = await initSocket();
      emitAgentJoin();
      registerUserStatus(getUserStatus);
      registerVisitorTypingHandler(visitorTYping);
      registerMessageHandler(onMessageReceived);
      registerConversationCreateHandler(onConversationCreateReceived);
      registerMessageRead(onMessageRead);
      registerAssigneeChangedHandler(onAssigneeStatusChange);
      registerStatusChangedHandler(onMsgStatusChanged);
      registerNote(onAddNote);
      registerCustomerProfile(onCustomerProfileChanged);
      setSocket(socket);
      reconnect();
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    if (appstate.appState === 'active') {
      connectSocket();
    }
  }, [appstate]);

  return <Component {...props} />;
};

export default SocketHOC;
